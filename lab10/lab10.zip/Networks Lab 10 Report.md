# 🚀** The mission**

_Write DDoS program that will spam the server with Sync request_

# **🚦**** Status**

_Program written and tested in Python_

# **⛳****  Milestones**

_This program can't connect to my previous version of the node in VM Ununtu_

# 📷** Screenshot**

![](https://storage.googleapis.com/slite-api-files-production/files/67d5c9d9-123c-4105-af0d-69b6acdcdd0d/image.png)

# How I done this?

In the loop I sending the '1' to the ip:port that asked to user write in console
