typedef struct _test_struct{
    char name[50];
    char age[50];
    char group[50];

} test_struct_t;


typedef struct result_struct_{

    char c[150]; // Это тоже

} result_struct_t;
