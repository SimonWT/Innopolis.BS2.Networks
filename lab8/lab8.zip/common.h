typedef struct word_struct{
    char word[50];
    int num;
    int max_num;

} word_struct;


typedef struct result_struct_{

    char c[150]; // Это тоже

} result_struct_t;
